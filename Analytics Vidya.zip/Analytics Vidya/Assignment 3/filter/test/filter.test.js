const fetchDataAndFilter = require("../src/filter"); // Import function

describe("fetchDataAndFilter", () => {
    test("matches full words", () => {
        const data = [{ title: "JavaScript" }, { title: "Python" }];
        expect(fetchDataAndFilter(data, "JavaScript")).toEqual([{ title: "JavaScript" }]);
    });

    test("matches case-insensitively", () => {
        const data = [{ title: "JavaScript" }, { title: "JAVA" }];
        expect(fetchDataAndFilter(data, "java")).toEqual([{ title: "JavaScript" }, { title: "JAVA" }]);
    });

    test("matches substrings", () => {
        const data = [{ title: "JavaScript" }, { title: "Python" }];
        expect(fetchDataAndFilter(data, "Script")).toEqual([{ title: "JavaScript" }]);
    });

    test("matches abbreviations (JS for JavaScript)", () => {
        const data = [
            { title: "JavaScript" },
            { title: "Java" },
            { title: "Just Start Coding" }, // "JS" should NOT match this
            { title: "Java Source" } // "JS" should match this too
        ];
        expect(fetchDataAndFilter(data, "JS")).toEqual([
            { title: "JavaScript" },
            { title: "Just Start Coding" }, 
            { title: "Java Source" }
        ]);
    });

    test("ignores special characters", () => {
        const data = [{ title: "C++ Programming" }];
        expect(fetchDataAndFilter(data, "CP")).toEqual([{ title: "C++ Programming" }]);
    });

    test("handles empty arrays", () => {
        expect(fetchDataAndFilter([], "JS")).toEqual([]);
    });

    test("handles missing title properties", () => {
        const data = [{ name: "No Title Here" }, { title: "JavaScript Basics" }];
        expect(fetchDataAndFilter(data, "JS")).toEqual([{ title: "JavaScript Basics" }]);
    });

    test("returns an empty array when keyword is empty", () => {
        expect(fetchDataAndFilter([{ title: "JavaScript" }], "")).toEqual([]);
    });
});


