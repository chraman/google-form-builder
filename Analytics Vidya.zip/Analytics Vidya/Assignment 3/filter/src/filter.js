function fetchDataAndFilter(data, keyword) {
    if (!Array.isArray(data) || typeof keyword !== "string" || keyword.trim() === "") {
        return [];
    }

    const lowerKeyword = keyword.toLowerCase();

    return data.filter(item => {
        if (typeof item.title !== "string") return false;

        const lowerTitle = item.title.toLowerCase();

        // Direct substring match
        if (lowerTitle.includes(lowerKeyword)) return true;

        // Partial abbreviation matching
        let abbreviation = item.title.replace(/[^A-Z]/g, '')
        return abbreviation.toLowerCase().includes(lowerKeyword);
    });
}


module.exports = fetchDataAndFilter; // Export the function for testing


