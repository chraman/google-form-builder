document.addEventListener("DOMContentLoaded", () => {
    const carousel = document.querySelector(".carousel");
    const items = document.querySelectorAll(".carousel-item");
    const prevBtn = document.querySelector(".prev");
    const nextBtn = document.querySelector(".next");
    let index = 0;
    
    function updateCarousel() {
        carousel.style.transform = `translateX(-${index * 100}%)`;
        lazyLoadImages();
    }
    
    function nextSlide() {
        index = (index + 1) % items.length;
        updateCarousel();
    }
    
    function prevSlide() {
        index = (index - 1 + items.length) % items.length;
        updateCarousel();
    }
    
    function lazyLoadImages() {
        const img = items[index].querySelector("img");
        if (!img.src) img.src = img.dataset.src;
    }
    
    nextBtn.addEventListener("click", nextSlide);
    prevBtn.addEventListener("click", prevSlide);
    
    document.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight") nextSlide();
        if (e.key === "ArrowLeft") prevSlide();
    });
    
    let touchStartX = 0;
    carousel.addEventListener("touchstart", (e) => touchStartX = e.touches[0].clientX);
    carousel.addEventListener("touchend", (e) => {
        let touchEndX = e.changedTouches[0].clientX;
        if (touchStartX - touchEndX > 50) nextSlide();
        if (touchEndX - touchStartX > 50) prevSlide();
    });
    
    lazyLoadImages();
});